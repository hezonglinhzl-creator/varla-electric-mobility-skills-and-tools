@echo off
explorer.exe "%~dp0app"
