# shopify-order-bot

Independent source package for the `shopify-order-bot` program or browser extension. The original program files are in [`app/`](app/). Double click `打开程序文件夹.cmd` on Windows and follow the program's own README or launcher. Install dependencies and configure accounts locally.

## Related Codex skills

- [skill-shopify-kol-order-automation](https://github.com/hezonglinhzl-creator/skill-shopify-kol-order-automation)
- [skill-varla-kol-feishu-order-writeback-skill](https://github.com/hezonglinhzl-creator/skill-varla-kol-feishu-order-writeback-skill)
- [skill-varla-uppromote-affiliate-automation](https://github.com/hezonglinhzl-creator/skill-varla-uppromote-affiliate-automation)

This package comes from the sanitized public release. It has no credentials, customer/KOL records, contracts, mail history, databases, or business media. Review included component licenses before use.
