# feishu-codex-local

Independent source package for the `feishu-codex-local` program or browser extension. The original program files are in [`app/`](app/). Double click `打开程序文件夹.cmd` on Windows and follow the program's own README or launcher. Install dependencies and configure accounts locally.

## Related Codex skills

- [skill-feishu-codex-local-link](https://github.com/hezonglinhzl-creator/skill-feishu-codex-local-link)
- [skill-codex-feishu-portable](https://github.com/hezonglinhzl-creator/skill-codex-feishu-portable)
- [skill-feishu-codex-local](https://github.com/hezonglinhzl-creator/skill-feishu-codex-local)
- [skill-varla-kol-feishu-order-writeback-skill](https://github.com/hezonglinhzl-creator/skill-varla-kol-feishu-order-writeback-skill)

This package comes from the sanitized public release. It has no credentials, customer/KOL records, contracts, mail history, databases, or business media. Review included component licenses before use.
