# varla-kol-reply-program

Independent source package for the `varla-kol-reply-program` program or browser extension. The original program files are in [`app/`](app/). Double click `打开程序文件夹.cmd` on Windows and follow the program's own README or launcher. Install dependencies and configure accounts locally.

## Related Codex skills

- [skill-varla-kol-reply-assistant](https://github.com/hezonglinhzl-creator/skill-varla-kol-reply-assistant)

This package comes from the sanitized public release. It has no credentials, customer/KOL records, contracts, mail history, databases, or business media. Review included component licenses before use.
