# Varla 社媒周报与月报 / Varla Social Weekly and Monthly Reports

**简体中文** | [English](README.en.md)

将用户提供的社媒截图和 CSV 按日期及平台核对，生成周环比、月报和飞书可粘贴表格。

[下载完整项目包](https://github.com/hezonglinhzl-creator/varla-electric-mobility-skills-and-tools/raw/main/packages/skill-varla-weekly-report.zip) · [全部项目](https://github.com/hezonglinhzl-creator/varla-electric-mobility-skills-and-tools)

## 功能特性

- 日期边界和可用数据检查
- 平台矩阵号与 KOL 指标合并
- 互动口径说明和粘贴表格

## 这个包里有什么

| 内容 | 位置 |
| --- | --- |
| 社媒周报模板资料 | [varla-weekly-report](apps/varla-weekly-report/README.md) |
| Skill 指令 | [SKILL.md](skill/周报skill/SKILL.md) |

## 下载和解压

1. 在本仓库点绿色 **Code → Download ZIP**，或者点上方“下载完整项目包”。
2. 下载完成后右键 ZIP，选择**全部解压**，打开能看到此 README 的文件夹。
3. 保留整个目录；先按下一节准备程序，再安装和使用对应 Skill。

## 1. 先准备程序

### 社媒周报模板资料 (`varla-weekly-report`)

Codex 与你自己的截图/CSV。

先进入 `apps/varla-weekly-report`。按平台汇总、日期核对和周月报工作流指引。

1. 本目录是模板和 Skill 资料，没有需启动的后台。
2. 在完整包根目录运行 `安装Skill.cmd` 后重新打开 Codex。
3. 提供自己的当前与对比周期、截图和 CSV，用 周报skill 指定统计平台。
4. 逐项核对日期、互动口径和缺失数据，再使用输出表格。

[查看完整程序与浏览器插件安装说明](apps/varla-weekly-report/README.md)

没有业务截图、数据或自动登录后台功能。

## 2. 再安装 Skill

1. 回到解压后的项目根目录，双击 `安装Skill.cmd`。
2. 安装器把 `skill/周报skill` 复制到 `%USERPROFILE%\.codex\skills\周报skill`。遇到同名 Skill 会跳过，留意窗口结果。
3. 重新打开 Codex，新建对话，使用下面的 Skill 名称和示例。
4. 公司策略禁止脚本时，可先阅读 install.ps1，或手动把整个 Skill 目录复制到同一目标位置。

## 3. 第一次怎么用

| 准备项 | 内容 |
| --- | --- |
| 输入 | 自己的统计截图、CSV、当前和对比周期。 |
| 输出 | 中文报告、指标汇总表和缺失数据说明。 |

```text
使用 周报skill，只统计我提供的 Instagram 数据，对比这两个周期；明确标注数据缺失日期，输出飞书可粘贴表。
```


## 当前限制与常见问题

varla-weekly-report 是模板/Skill 资料，没有独立网页程序；公开包不含业务截图、CSV 和历史报表。

| 问题 | 怎么处理 |
| --- | --- |
| 找不到 Skill | 检查安装窗口结果和目标 SKILL.md，重新打开 Codex 并新建对话。 |
| 程序启动失败 | 在程序目录打开 PowerShell 运行本文命令，让错误保留在窗口，再对照对应程序 README。 |
| 网页看不到插件 | 确认选中直接包含 manifest.json 的目录、网站受支持，并刷新网页。 |
| 外部服务不可用 | 配置自己的授权并检查资源权限；保留本地结果，不把失败说成同步/发送成功。 |

## 隐私与验证范围

这是程序源码与 Skill 分发包，不附带真实账号、OAuth 令牌、客户/KOL 台账、合同、订单、邮箱导出或业务媒体。服务需使用自己的配置。已检查文档和包内入口；此次文档核对没有执行真实下单、发邮件或发布内容。
