# dreamina-image2video

Independent source package for the `dreamina-image2video` program or browser extension. The original program files are in [`app/`](app/). Double click `打开程序文件夹.cmd` on Windows and follow the program's own README or launcher. Install dependencies and configure accounts locally.

## Related Codex skills

- [skill-image2-motion-agent](https://github.com/hezonglinhzl-creator/skill-image2-motion-agent)

This package comes from the sanitized public release. It has no credentials, customer/KOL records, contracts, mail history, databases, or business media. Review included component licenses before use.
