# video-storyboard-tool

Independent source package for the `video-storyboard-tool` program or browser extension. The original program files are in [`app/`](app/). Double click `打开程序文件夹.cmd` on Windows and follow the program's own README or launcher. Install dependencies and configure accounts locally.

## Related Codex skills

- [skill-benchmark-video-skill-builder](https://github.com/hezonglinhzl-creator/skill-benchmark-video-skill-builder)
- [skill-viral-product-video-replicator](https://github.com/hezonglinhzl-creator/skill-viral-product-video-replicator)

This package comes from the sanitized public release. It has no credentials, customer/KOL records, contracts, mail history, databases, or business media. Review included component licenses before use.
